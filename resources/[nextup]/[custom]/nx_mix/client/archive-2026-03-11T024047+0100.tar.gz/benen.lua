-- nx_merged | benen.lua
-- Detecteert schade aan beenbotten en zet de speler in ragdoll

local LEG_BONES = {
    [0xE39F] = true, -- SKEL_L_Thigh
    [0xCA72] = true, -- SKEL_R_Thigh
    [0xF9BB] = true, -- SKEL_L_Calf
    [0x9000] = true, -- SKEL_R_Calf
    [0x3779] = true, -- SKEL_L_Foot
    [0xCC4D] = true, -- SKEL_R_Foot
    [0x83C]  = true, -- SKEL_L_Toe0
    [0x512D] = true, -- SKEL_R_Toe0
}

local ragdolling = false

CreateThread(function()
    while true do
        Wait(1000)
        local ped = PlayerPedId()
        if not IsPedInAnyVehicle(ped, false) and not ragdolling then
            if HasEntityBeenDamagedByAnyPed(ped) or HasEntityBeenDamagedByAnyObject(ped) or HasEntityBeenDamagedByAnyVehicle(ped) then
                local hit, bone = GetPedLastDamageBone(ped)
                if Config.debug_bone and hit then
                    print(("[DEBUG benen] Bone-id: %s"):format(tostring(bone)))
                end
                if hit and bone and LEG_BONES[bone] then
                    ragdolling = true
                    SetPedToRagdoll(ped, Config.ragdoll_tijd, Config.ragdoll_tijd, 0, false, false, false)
                    Wait(Config.ragdoll_tijd + 300)
                    ragdolling = false
                end
                ClearPedLastDamageBone(ped)
                ClearEntityLastDamageEntity(ped)
            end
        end
    end
end)
